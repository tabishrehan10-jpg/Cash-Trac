package com.example.util

import com.example.data.Categories
import com.example.data.ExpenseTransaction
import com.example.data.PaymentMode
import com.example.data.TransactionType
import java.util.regex.Pattern

data class ParsedExpense(
    val title: String,
    val amount: Double,
    val type: TransactionType,
    val category: String,
    val paymentMode: PaymentMode,
    val confidence: Float,
    val rawText: String
)

object ExpenseParser {

    private val amountRegex = Pattern.compile(
        """(?:rs\.?|inr|₹)?\s*([0-9]+(?:,[0-9]+)*(?:\.[0-9]{1,2})?|\b[0-9]+(?:\.[0-9]{1,2})?\s*(?:k|lakh|lac)?)\s*(?:rs\.?|inr|rupees)?""",
        Pattern.CASE_INSENSITIVE
    )

    fun parseInput(input: String, sourceTag: String = "CHAT"): ParsedExpense {
        val trimmed = input.trim()
        val lower = trimmed.lowercase()

        // 1. Detect Type
        // Note: remove "credit card" phrases before checking for income keywords like "credit"
        val textWithoutPaymentModes = lower
            .replace("credit card", "")
            .replace("creditcard", "")
            .replace("debit card", "")
            .replace("debitcard", "")

        val incomeKeywords = listOf("received", "got", "credited", "salary", "dividend", "cashback", "bonus", "refund", "earned", "income")
        val isIncome = incomeKeywords.any { textWithoutPaymentModes.contains(it) } ||
                Regex("""\bcredit\b""").containsMatchIn(textWithoutPaymentModes)
        val type = if (isIncome) TransactionType.INCOME else TransactionType.EXPENSE

        // 2. Detect Amount
        var amount = extractAmount(lower)
        if (amount <= 0.0) {
            // fallback search for any number
            val simpleNum = Pattern.compile("""\b\d+(?:\.\d{1,2})?\b""").matcher(lower)
            if (simpleNum.find()) {
                amount = simpleNum.group().toDoubleOrNull() ?: 100.0
            } else {
                amount = 100.0
            }
        }

        // 3. Detect Payment Mode
        val paymentMode = when {
            lower.contains("upi") || lower.contains("gpay") || lower.contains("phonepe") || lower.contains("paytm") -> PaymentMode.UPI
            lower.contains("cash") -> PaymentMode.CASH
            lower.contains("credit card") || lower.contains("creditcard") || lower.contains(" cc ") -> PaymentMode.CREDIT_CARD
            lower.contains("debit card") || lower.contains("debitcard") || lower.contains(" dc ") -> PaymentMode.DEBIT_CARD
            lower.contains("net banking") || lower.contains("bank transfer") || lower.contains("neft") || lower.contains("rtgs") -> PaymentMode.NET_BANKING
            else -> PaymentMode.UPI
        }

        // 4. Detect Category
        val category = if (type == TransactionType.INCOME) {
            detectIncomeCategory(lower)
        } else {
            detectExpenseCategory(lower)
        }

        // 5. Generate Title
        val title = generateTitle(trimmed, category, type, amount)

        return ParsedExpense(
            title = title,
            amount = amount,
            type = type,
            category = category,
            paymentMode = paymentMode,
            confidence = 0.92f,
            rawText = input
        )
    }

    private fun extractAmount(text: String): Double {
        val matcher = amountRegex.matcher(text)
        var bestAmount = 0.0
        while (matcher.find()) {
            val match = matcher.group(1)?.replace(",", "") ?: continue
            val numVal = if (match.endsWith("k", ignoreCase = true)) {
                (match.dropLast(1).trim().toDoubleOrNull() ?: 0.0) * 1000
            } else if (match.endsWith("lakh", ignoreCase = true) || match.endsWith("lac", ignoreCase = true)) {
                (match.replace(Regex("(lakh|lac)", RegexOption.IGNORE_CASE), "").trim().toDoubleOrNull() ?: 0.0) * 100000
            } else {
                match.toDoubleOrNull() ?: 0.0
            }
            if (numVal > 0.0) {
                bestAmount = numVal
                break
            }
        }
        return bestAmount
    }

    private fun detectExpenseCategory(text: String): String {
        return when {
            text.contains("grocery") || text.contains("groceries") || text.contains("vegetable") || text.contains("fruits") || text.contains("milk") || text.contains("supermarket") || text.contains("blinkit") || text.contains("zepto") || text.contains("bigbasket") || text.contains("d-mart") || text.contains("dmart") -> "Groceries"
            text.contains("food") || text.contains("dining") || text.contains("lunch") || text.contains("dinner") || text.contains("breakfast") || text.contains("swiggy") || text.contains("zomato") || text.contains("restaurant") || text.contains("pizza") || text.contains("burger") || text.contains("cafe") || text.contains("coffee") || text.contains("tea") || text.contains("chai") || text.contains("biryani") -> "Food & Dining"
            text.contains("petrol") || text.contains("diesel") || text.contains("fuel") || text.contains("uber") || text.contains("ola") || text.contains("cab") || text.contains("auto") || text.contains("metro") || text.contains("bus") || text.contains("toll") || text.contains("parking") || text.contains("rapido") -> "Transport & Fuel"
            text.contains("rent") || text.contains("maintenance") || text.contains("flat") || text.contains("society") || text.contains("house") -> "Housing & Rent"
            text.contains("bill") || text.contains("electricity") || text.contains("water") || text.contains("gas") || text.contains("wifi") || text.contains("recharge") || text.contains("broadband") || text.contains("mobile") || text.contains("cylinder") -> "Utilities & Bills"
            text.contains("shop") || text.contains("amazon") || text.contains("flipkart") || text.contains("clothes") || text.contains("shoes") || text.contains("myntra") || text.contains("zara") || text.contains("gadget") || text.contains("electronics") -> "Shopping"
            text.contains("movie") || text.contains("netflix") || text.contains("cinema") || text.contains("game") || text.contains("concert") || text.contains("outing") || text.contains("party") || text.contains("hotstar") || text.contains("prime") -> "Entertainment"
            text.contains("medicine") || text.contains("doctor") || text.contains("hospital") || text.contains("clinic") || text.contains("pharmacy") || text.contains("tablet") || text.contains("health") || text.contains("test") -> "Healthcare & Meds"
            text.contains("school") || text.contains("college") || text.contains("fees") || text.contains("course") || text.contains("books") || text.contains("tuition") -> "Education"
            text.contains("salon") || text.contains("spa") || text.contains("haircut") || text.contains("gym") || text.contains("fitness") -> "Personal Care"
            text.contains("gift") || text.contains("donation") || text.contains("charity") || text.contains("shagun") -> "Gifts & Donations"
            else -> "Other Expense"
        }
    }

    private fun detectIncomeCategory(text: String): String {
        return when {
            text.contains("salary") || text.contains("paycheck") || text.contains("wage") || text.contains("payroll") -> "Salary"
            text.contains("freelance") || text.contains("client") || text.contains("project") || text.contains("business") || text.contains("contract") -> "Business/Freelance"
            text.contains("stock") || text.contains("mutual fund") || text.contains("dividend") || text.contains("crypto") || text.contains("trading") || text.contains("shares") -> "Investments"
            text.contains("rent received") || text.contains("tenant") || text.contains("property") -> "Rental Income"
            text.contains("cashback") || text.contains("reward") || text.contains("scratch card") -> "Cashback & Rewards"
            text.contains("gift") || text.contains("shagun") || text.contains("present") -> "Gifts Received"
            text.contains("refund") || text.contains("reversal") || text.contains("returned") -> "Refunds"
            else -> "Other Income"
        }
    }

    private fun generateTitle(input: String, category: String, type: TransactionType, amount: Double): String {
        // Remove amount tokens and common fluff words to make a clean title
        var title = input
            .replace(Regex("""(?i)\b(i\s+)?(paid|spent|gave|bought|received|got|credited|debited|for|to|on|via|by|with|using|rs|inr|rupees)\b"""), " ")
            .replace(Regex("""\b\d+(?:,\d+)*(?:\.\d+)?\b"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()

        if (title.isBlank() || title.length < 3) {
            return if (type == TransactionType.INCOME) "$category Credit" else "$category Expense"
        }
        return title.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }
}
