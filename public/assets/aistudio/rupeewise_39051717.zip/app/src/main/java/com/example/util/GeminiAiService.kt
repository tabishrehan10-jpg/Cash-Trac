package com.example.util

import android.graphics.Bitmap
import android.util.Log
import com.example.data.Categories
import com.example.data.ExpenseTransaction
import com.example.data.PaymentMode
import com.example.data.TransactionType
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private const val TAG = "GeminiAiService"

data class ExtractionResult(
    val transactions: List<StatementItem>,
    val conversationalSummary: String,
    val isSuccess: Boolean = true,
    val errorMessage: String? = null
)

object GeminiAiService {

    // Schema for structured JSON extraction
    private val transactionSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "title" to Schema.string(description = "Merchant or brief title of transaction"),
                "amount" to Schema.double(description = "Transaction monetary amount as positive number"),
                "type" to Schema.string(description = "Either EXPENSE or INCOME"),
                "category" to Schema.string(description = "Category: Food, Shopping, Groceries, Bills, Fuel, Health, Entertainment, Travel, Salary, Investment, or Others"),
                "paymentMode" to Schema.string(description = "Payment mode: UPI, Credit Card, Debit Card, Cash, Net Banking, or Wallet"),
                "date" to Schema.string(description = "Date string in YYYY-MM-DD or DD/MM/YYYY format if present", nullable = true),
                "note" to Schema.string(description = "Additional transaction note, reference number, or particulars", nullable = true)
            ),
            optionalProperties = listOf("date", "note")
        )
    }

    private val extractionSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "transactions" to Schema.array(
                    items = transactionSchema,
                    description = "List of all financial transactions detected from the input"
                ),
                "analysisSummary" to Schema.string(
                    description = "Brief conversational summary of detected transactions"
                )
            ),
            optionalProperties = listOf("analysisSummary")
        )
    }

    private val structuredModel by lazy {
        val config = generationConfig {
            responseMimeType = "application/json"
            responseSchema = extractionSchema
        }
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = config
        )
    }

    private val conversationalModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash"
        )
    }

    /**
     * Extracts structured transactions from natural language text, bank SMS messages,
     * or pasted statement rows using Gemini 3.8 Flash.
     */
    suspend fun extractFromText(rawText: String): ExtractionResult = withContext(Dispatchers.IO) {
        val prompt = """
            You are an expert personal finance and bank statement parsing AI for RupeeWise.
            Extract all financial transactions from the following user input, SMS, receipt, or statement text.
            Classify each transaction accurately:
            - amount: positive numeric value (e.g. 350.0)
            - type: EXPENSE or INCOME (salary, refund, received money is INCOME; purchases, bills, debits are EXPENSE)
            - category: choose the best fitting from [Food, Shopping, Groceries, Bills, Fuel, Health, Entertainment, Travel, Salary, Investment, Others]
            - paymentMode: choose from [UPI, Credit Card, Debit Card, Cash, Net Banking, Wallet]
            - title: merchant or concise description (e.g. 'Swiggy', 'Starbucks', 'Electricity Bill')
            - date: in YYYY-MM-DD format if mentioned, otherwise leave empty
            - note: any reference number or remarks

            Text to analyze:
            $rawText
        """.trimIndent()

        try {
            val response = withTimeout(60_000L) {
                structuredModel.generateContent(prompt)
            }
            val jsonText = response.text
            if (jsonText.isNullOrBlank()) {
                return@withContext fallbackTextExtraction(rawText, "AI returned empty text response")
            }
            parseJsonToExtractionResult(jsonText, rawText)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini extraction timed out", e)
            fallbackTextExtraction(rawText, "AI extraction timed out, used fast local parser")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini extraction failed: ${e.message}", e)
            fallbackTextExtraction(rawText, e.localizedMessage ?: "AI extraction error")
        }
    }

    /**
     * Multimodal extraction from image bitmaps (receipts, printed statements, invoices).
     */
    suspend fun extractFromImage(bitmap: Bitmap, promptHint: String? = null): ExtractionResult = withContext(Dispatchers.IO) {
        val prompt = """
            You are an expert personal finance AI assistant for RupeeWise.
            Carefully read this uploaded document/receipt/statement image.
            Extract every single financial transaction line item, bill item, or statement row.
            Determine amount, whether it is an EXPENSE or INCOME, category, payment mode, merchant/title, and date.
            ${promptHint ?: ""}
        """.trimIndent()

        try {
            val response = withTimeout(60_000L) {
                structuredModel.generateContent(
                    content {
                        text(prompt)
                        image(bitmap)
                    }
                )
            }
            val jsonText = response.text
            if (jsonText.isNullOrBlank()) {
                return@withContext ExtractionResult(
                    transactions = emptyList(),
                    conversationalSummary = "Could not detect clear transaction lines in the image.",
                    isSuccess = false,
                    errorMessage = "Empty response from Gemini vision model"
                )
            }
            parseJsonToExtractionResult(jsonText, "Image document")
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini image extraction timed out", e)
            ExtractionResult(
                transactions = emptyList(),
                conversationalSummary = "AI analysis timed out. Please try a clearer picture or upload CSV.",
                isSuccess = false,
                errorMessage = "Timeout"
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini image extraction failed: ${e.message}", e)
            ExtractionResult(
                transactions = emptyList(),
                conversationalSummary = "AI could not process this image: ${e.localizedMessage}",
                isSuccess = false,
                errorMessage = e.localizedMessage
            )
        }
    }

    /**
     * Answers conversational financial questions from the user with current monthly ledger context.
     */
    suspend fun askFinancialAdvisor(userQuestion: String, ledgerContext: String): String = withContext(Dispatchers.IO) {
        val systemPrompt = """
            You are RupeeWise AI, an intelligent, polite, and encouraging Indian personal finance advisor.
            You have access to the user's current monthly financial overview:
            $ledgerContext

            Answer the user's question concisely, helpfully, and with realistic financial advice.
            Use Indian Rupees (₹) when referencing amounts. Keep answers within 2-4 sentences unless detailed analysis is requested.
        """.trimIndent()

        try {
            val response = withTimeout(60_000L) {
                conversationalModel.generateContent("$systemPrompt\n\nUser Question: $userQuestion")
            }
            response.text ?: "I reviewed your ledger. How else can I assist with your expenses today?"
        } catch (e: TimeoutCancellationException) {
            "Analysis timed out. Please try asking again."
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Conversational advisor failed: ${e.message}", e)
            "I'm here to help manage your expenses! You can log items like 'Paid ₹350 for dinner UPI' or upload your bank statement."
        }
    }

    private fun parseJsonToExtractionResult(jsonText: String, originalText: String): ExtractionResult {
        return try {
            val root = JSONObject(jsonText)
            val summary = root.optString("analysisSummary", "")
            val txArray = root.optJSONArray("transactions")

            val items = mutableListOf<StatementItem>()
            if (txArray != null) {
                for (i in 0 until txArray.length()) {
                    val obj = txArray.getJSONObject(i)
                    val rawTitle = obj.optString("title", "Expense").trim()
                    val amount = obj.optDouble("amount", 0.0)
                    if (amount <= 0.0 && rawTitle.isBlank()) continue

                    val typeStr = obj.optString("type", "EXPENSE").uppercase()
                    val type = if (typeStr == "INCOME") TransactionType.INCOME else TransactionType.EXPENSE

                    val categoryStr = obj.optString("category", "Others")
                    val category = sanitizeCategory(categoryStr, type)

                    val modeStr = obj.optString("paymentMode", "UPI")
                    val paymentMode = sanitizePaymentMode(modeStr)

                    val dateStr = obj.optString("date", "")
                    val timestamp = parseDateStringToTimestamp(dateStr)

                    val note = obj.optString("note", "")

                    items.add(
                        StatementItem(
                            id = UUID.randomUUID().toString(),
                            title = if (rawTitle.isBlank()) category else rawTitle,
                            amount = Math.abs(amount),
                            type = type,
                            category = category,
                            paymentMode = paymentMode,
                            timestamp = timestamp,
                            note = note,
                            originalText = originalText.take(120),
                            isSelected = true
                        )
                    )
                }
            }

            val finalSummary = if (summary.isNotBlank()) {
                summary
            } else if (items.isNotEmpty()) {
                "AI successfully identified ${items.size} transaction${if (items.size > 1) "s" else ""}."
            } else {
                "No clear transactions identified."
            }

            ExtractionResult(
                transactions = items,
                conversationalSummary = finalSummary,
                isSuccess = items.isNotEmpty()
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing JSON from Gemini: ${e.message}", e)
            fallbackTextExtraction(originalText, "JSON parse error")
        }
    }

    private fun fallbackTextExtraction(text: String, reason: String): ExtractionResult {
        val parsed = ExpenseParser.parseInput(text, sourceTag = "CHAT_FALLBACK")
        val item = StatementItem(
            id = UUID.randomUUID().toString(),
            title = parsed.title,
            amount = parsed.amount,
            type = parsed.type,
            category = parsed.category,
            paymentMode = parsed.paymentMode,
            timestamp = System.currentTimeMillis(),
            note = "Parsed via local engine ($reason)",
            originalText = text.take(120),
            isSelected = true
        )
        return ExtractionResult(
            transactions = listOf(item),
            conversationalSummary = "Recognized ${parsed.type.name.lowercase()} of ${CurrencyFormatter.formatCurrency(parsed.amount)} for \"${parsed.title}\" (${parsed.category}).",
            isSuccess = true,
            errorMessage = reason
        )
    }

    private fun sanitizeCategory(rawCategory: String, type: TransactionType): String {
        val list = if (type == TransactionType.INCOME) Categories.incomeCategories else Categories.expenseCategories
        return list.firstOrNull { it.name.equals(rawCategory, ignoreCase = true) }?.name
            ?: list.firstOrNull { rawCategory.contains(it.name, ignoreCase = true) }?.name
            ?: if (type == TransactionType.INCOME) "Salary" else "Others"
    }

    private fun sanitizePaymentMode(rawMode: String): PaymentMode {
        val lower = rawMode.lowercase()
        return when {
            lower.contains("upi") || lower.contains("gpay") || lower.contains("phonepe") || lower.contains("paytm") -> PaymentMode.UPI
            lower.contains("credit") -> PaymentMode.CREDIT_CARD
            lower.contains("debit") -> PaymentMode.DEBIT_CARD
            lower.contains("net") || lower.contains("bank") || lower.contains("neft") || lower.contains("rtgs") || lower.contains("imps") -> PaymentMode.NET_BANKING
            lower.contains("wallet") -> PaymentMode.WALLET
            lower.contains("cash") -> PaymentMode.CASH
            else -> PaymentMode.UPI
        }
    }

    private fun parseDateStringToTimestamp(dateStr: String): Long {
        if (dateStr.isBlank()) return System.currentTimeMillis()
        val formats = listOf(
            "yyyy-MM-dd",
            "dd/MM/yyyy",
            "dd-MM-yyyy",
            "dd MMM yyyy",
            "yyyy/MM/dd",
            "dd.MM.yyyy"
        )
        for (format in formats) {
            try {
                val sdf = SimpleDateFormat(format, Locale.US)
                val date = sdf.parse(dateStr)
                if (date != null) return date.time
            } catch (_: Exception) {}
        }
        return System.currentTimeMillis()
    }
}
